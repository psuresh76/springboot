package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.model.Employee;

@Component
public class EmployeeService {
	
	static List<Employee> e = new ArrayList<>();
	
	static {
		e.add(new Employee(1, "Suresh"));
		e.add(new Employee(2, "Pelluru"));
		e.add(new Employee(3, "Java"));
		e.add(new Employee(4, "Test"));
		
	}
	
	public String getEmployee() {
		return "Suresh";
	}
	
	public List<Employee> getAllEmployees() {
		return e;
	}

}
