package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "Demo API", description = "Demo Application using Rest API")
public class EmployeeController {
	
	@Autowired
	EmployeeService es;
	
	
	@GetMapping("/employee")
	@ApiOperation(value = "Get one employee detail")
	public String getEmployee(){
		String emp = es.getEmployee();
		return emp;
	}
	
	
	@GetMapping("/employeelist")
	@ApiOperation(value = "Get all employee details")
	public List<Employee> getAllEmployees(){
		List<Employee> emp = es.getAllEmployees();
	
		return emp;
	}
	
	@PostMapping("/addemployee")
	@ApiOperation(value = "Add an employee to the system")
	public List<Employee>  addEmployee(@RequestBody Employee e){
		List<Employee> emp = es.addEmployee(e);
		return emp;
	}

}
